"use client";

import React from "react";

export function Layout3() {
  return (
    <section className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="grid grid-cols-1 gap-y-12 md:grid-cols-2 md:items-center md:gap-x-12 lg:gap-x-20">
          <div>
            <h1 className="heading-h3 mb-5 font-bold md:mb-6">
              Empowering Employees: Reskill for Tomorrow's Opportunities with
              Our Redeployed Services
            </h1>
            <p className="text-medium">
              Our Redeployed Services help employees transition smoothly into
              future-ready roles. With personalized skill assessments and
              tailored learning pathways, we ensure every individual is equipped
              for success.
            </p>
          </div>
          <div>
            <img
              src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
              className="w-full rounded-image object-cover"
              alt="Relume placeholder image"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
